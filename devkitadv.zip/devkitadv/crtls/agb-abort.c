void abort (void)
{
  for(;;);
}



