void _raise (void)
{
  /* function not implemented */
}



