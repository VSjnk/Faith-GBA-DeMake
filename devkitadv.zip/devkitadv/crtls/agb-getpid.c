int _getpid (void)
{
  return 1;
}



