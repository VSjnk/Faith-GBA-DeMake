/* newlib.h.  Generated automatically by configure.  */
#ifndef __NEWLIB_H__

#define __NEWLIB_H__ 1

/* EL/IX level */
/* #undef _ELIX_LEVEL */

/* Newlib version */
#define _NEWLIB_VERSION "1.11.0"

/* MB_LEN_MAX */
/* #undef _MB_LEN_MAX */

#endif /* !__NEWLIB_H__ */

